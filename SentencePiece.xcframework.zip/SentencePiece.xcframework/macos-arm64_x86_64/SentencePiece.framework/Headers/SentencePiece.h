//
//  SentencePiece.h
//  Umbrella header for SentencePiece framework
//

#ifndef SENTENCEPIECE_H
#define SENTENCEPIECE_H

#include <sentencepiece_processor.h>
#include <sentencepiece_trainer.h>

#endif /* SENTENCEPIECE_H */
